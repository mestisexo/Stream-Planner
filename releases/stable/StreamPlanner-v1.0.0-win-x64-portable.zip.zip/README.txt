﻿Stream Planner 1.0.0 - Windows x64

USO
1. Descomprime este paquete en una carpeta.
2. Ejecuta StreamPlanner.exe.

DATOS
La base de datos debe guardarse en:
%LOCALAPPDATA%\StreamPlanner\stream_planner.db

No borres esa carpeta para actualizar la aplicación:
contiene los datos personales del usuario.

REQUISITOS
Windows x64. Esta versión no requiere Visual Studio
para ejecutarse, siempre que sus dependencias estén
incluidas o disponibles en Windows.
